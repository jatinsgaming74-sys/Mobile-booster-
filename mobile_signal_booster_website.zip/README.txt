MOBILE SIGNAL BOOSTER AHMEDABAD - WEBSITE

Files:
- index.html: website content and working contact links
- style.css: responsive styling
- script.js: mobile navigation and current year

CONTACT NUMBERS:
- Main Call / WhatsApp: +91 98215 29694
- Banner call number: +91 88230 37771
These are the numbers visible in the screenshot you supplied. Confirm that you own or are authorized to use them before publishing.

To change the main number:
- In index.html, update href="tel:+919821529694"
- For WhatsApp, update https://wa.me/919821529694 (country code + number, digits only)
- Update any repeated links too.

Open index.html in a browser to preview. Upload all three files to a static host to publish online.
